const mysql = require("mysql");
const axios = require("axios");
const urlPrefix = "http://store.steampowered.com/api/appdetails?appids=";

// Connection to the database.
const con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "mysql",
  database: "capstone"
});
con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
});

fetchSteamData("The Elder Scrolls V: Skyrim");

async function fetchSteamData(name) {
  con.query(`SELECT * FROM steam WHERE name = '${name}'`, async function(
    err,
    result
  ) {
    if (err) throw err;
    // Get the appid matching the given name from the database.
    appid = result[0].appid;
    const json = await axios.get(urlPrefix + appid);
    const game = json.data;
    console.log(game);
  });
}

async function insertAllGamesIntoDB() {
  var allGamesJson = await axios.get(
    "http://api.steampowered.com/ISteamApps/GetAppList/v0002/"
  );
  var allGames = allGamesJson.data.applist.apps;
  allGames.forEach(game => {
    if (game.name.includes('"')) {
      console.log(game);
    } else {
      var appid = game["appid"];
      var name = '"' + game["name"] + '"';
      var sql =
        // Ignore duplicate values.
        "INSERT IGNORE INTO steam (appid, name) VALUES (" +
        appid +
        ", " +
        name +
        ")";
      // Insert into the database.
      con.query(sql, function(err, result) {
        if (err) throw err;
        //console.log("Number of records inserted: " + result.affectedRows);
      });
    }
  });

  module.exports.initializeFetcher = initializeFetcher;
}
